/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.awt.Desktop;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCombination;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.print.attribute.PrintRequestAttributeSet;

/**
 *
 * @author Hao
 */
public class NewMenubar extends MenuBar{
    
    Menu file, support, edit;
    
    private void initializeFile() {
        file = new Menu("File");
        
        MenuItem newMenuItem = new MenuItem("New");
        MenuItem openMenuItem = new MenuItem("Open");
        MenuItem saveMenuItem = new MenuItem("Save");
        MenuItem saveAsMenuItem = new MenuItem("Save As");
        MenuItem importMenuItem = new MenuItem("Import");
        MenuItem exportMenuItem = new MenuItem("Export");
        
        //to do: "new Text("")" needs to be changed into the one we want to print
        MenuItem printMenuItem = new MenuItem("Print");
        printMenuItem.setOnAction( (ActionEvent event) -> {
            PrinterJob print = PrinterJob.getPrinterJob();
            if (print != null) {
                if (print.printDialog()) {
                    try {
                        print.print((PrintRequestAttributeSet) new Text(""));
                    } catch (PrinterException ex) {
                        Logger.getLogger(NewMenubar.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
        
        MenuItem exitMenuItem = new MenuItem("Exit");
        exitMenuItem.setMnemonicParsing(true);
        //we can set hotkey if we want, this is an halfway example. No hotkey has been related to the function
        exitMenuItem.setAccelerator(KeyCombination.NO_MATCH);
        exitMenuItem.setOnAction( (ActionEvent event) -> {
            Platform.exit();
        });
        
        file.getItems().addAll(newMenuItem, openMenuItem, saveMenuItem, saveAsMenuItem, importMenuItem, exportMenuItem,printMenuItem,exitMenuItem);
    }
    
    private void initializeEdit(){
        edit = new Menu("Edit");
        
        MenuItem undoMenuItem = new MenuItem("Undo");
        MenuItem redoMenuItem = new MenuItem("Redo");
        MenuItem cutMenuItem = new MenuItem("Cut");
        MenuItem copyMenuItem = new MenuItem("Copy");
        MenuItem pasteMenuItem = new MenuItem("Paste");
        MenuItem deleteMenuItem = new MenuItem("Delete");
        
        edit.getItems().addAll(undoMenuItem, redoMenuItem, cutMenuItem, copyMenuItem, pasteMenuItem, deleteMenuItem);
        
    }
    
    private void initializeSupport() {
        support = new Menu("Support");
        
        MenuItem developerMenuItem = new MenuItem("About Developers");
        developerMenuItem.setOnAction( (ActionEvent event) -> {
           Stage stage = new Stage();
           Scene dialog = new Scene(new Group(new Text(
                     "\nEasy As Paint GUI Design Editor \n \n"
                    + "This application is powered by JavaFX \n"
                    + "By group: \n \n"
                    + "  Ben Hardy  BBH219 \n"
                    + "  Hao Li     Hal215 \n")));
           dialog.setFill(Color.GAINSBORO);
           stage.setScene(dialog);
           stage.show();
        });
        
        MenuItem oracleMenuItem = new MenuItem("Oracle JavaFX Guide");
        oracleMenuItem.setOnAction((ActionEvent event) -> {
           try {
               Desktop.getDesktop().browse(new URI("http://docs.oracle.com/javase/8/javase-clienttechnologies.htm"));
               //URI of overview-summary: docs.oracle.com/javafx/2/api/overview-summary/html
           } catch (IOException | URISyntaxException e) {
           }
        });
        
        MenuItem formatMenuItem = new MenuItem("Saved File Format");
        formatMenuItem.setOnAction((ActionEvent event) -> {
            //since the format explanation may be too long, read from file
            StringBuilder content = new StringBuilder();
            TextArea textArea = new TextArea();
            
            InputStream inputStream = getClass().getResourceAsStream("format.txt");
            
            if (inputStream == null) {
                System.out.println("input stream is null");
            } else {
                BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
                try  {
                    String newline;
                    while ((newline = bufferedReader.readLine()) != null) {
                        content.append(newline).append("\n");
                    } 
                } catch (IOException ex) {
                        Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
                }
            }
            textArea.appendText(content.toString());
            textArea.setEditable(false);
            
            Stage stage = new Stage();
            stage.setMinHeight(400);
            stage.setMinWidth(600);
            textArea.prefHeightProperty().bind(stage.heightProperty());
            textArea.prefWidthProperty().bind(stage.widthProperty());
            Scene dialog = new Scene(new Group(textArea));
            dialog.setFill(Color.GAINSBORO);
            stage.setScene(dialog);
            stage.show();
        });
        
        support.getItems().addAll(formatMenuItem,developerMenuItem, oracleMenuItem);
    }
    
    public NewMenubar () {
        super();
        this.setMaxHeight(30);
        this.setMinHeight(30);
        this.setPadding(new Insets(0,0,0,0));
        
        initializeFile();
        initializeSupport();
        initializeEdit();
        
        this.getMenus().addAll(file,edit,support);
    }
    
}
