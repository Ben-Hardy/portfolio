/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

//import static Controller.actions.*;
import java.awt.Desktop;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import org.controlsfx.dialog.*;

/**
 * It is old design that saved as backup and should not be used.
 * @author Hao
 */
public class Toolbar extends HBox{
    
    // junk buttons
    Button open,save;   
    
    Button font;
    
    NewMenubar menubar;
    
    //for using it, example: Color color = colorPicker.getValue();
    ColorPicker colorPicker;
    
    //warning: this is junk method used for saving the work progress of file I/O, and should not be used at all
    private void initializeOpen () {
        open = new Button("Open");
        HBox.setHgrow(open, Priority.ALWAYS);
        open.setMaxWidth(Double.MAX_VALUE);
        
        open.setOnAction((final ActionEvent e) -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().addAll(
                    //TODO need to know the abbreviate of EAP GUI Project
                    new FileChooser.ExtensionFilter("EAP GUI Project", "")
            );
            fileChooser.setTitle("");
            
            File file = fileChooser.showOpenDialog(null);
            if (file != null) {
                try {
                    Desktop.getDesktop().open(file);
                } catch (IOException ex) {
                    Logger.getLogger(Toolbar.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    
    //TODO the action actually is for saveAs, but for changing save into saveAs, file name is needed to know  
    //warning: this is junk method, and should not be used at all
    private void initializeSave() {
        save = new Button("Save");
        HBox.setHgrow(save, Priority.ALWAYS);
        save.setMaxWidth(Double.MAX_VALUE);
        save.setOnAction((ActionEvent e) -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(
                    //TODO need to know the abbreviate of EAP GUI Project
                    new FileChooser.ExtensionFilter("EAP GUI Project", "")
            );
            File file = fileChooser.showSaveDialog(null);
            if (file != null) {
                if (!file.getName().contains(".")) {
                    //file = new File (file.getAbsolutePath() + "");
                }
                //TODO change"" into the actual content
                //saveFile("", file);
            }
        });
    }
    
    private void initializeFontButton() {
        font = new Button("Set Font");
        font.setFont(Font.font("Times New Roman"));
        font.setMinHeight(30);
        font.setMaxHeight(30);

        font.setOnAction(e -> {
            Optional<Font> response = Dialogs.create()
                .owner(null)
                .masthead("Choose what you like")
                .showFontSelector(font.getFont());
            font.setFont(response.get());
        });
    }
    
    public Toolbar () {
        super();
        
        this.setHeight(30);
        
        menubar = new NewMenubar();
        
        colorPicker = new ColorPicker();
        colorPicker.setValue(Color.WHITE);
        colorPicker.setMinHeight(30);
        colorPicker.setMaxHeight(30);
        
        initializeFontButton();
        this.getChildren().addAll(menubar, font, colorPicker);
    }
}
