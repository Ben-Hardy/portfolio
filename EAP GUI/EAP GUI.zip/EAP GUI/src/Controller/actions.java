/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author Hao
 */
public class actions {
    
    public static void saveFile(String content, File file){
        try {
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(content);
            fileWriter.close();;
        } catch (IOException ex) {
            
        }
    }
    
    /**
     * set fileChooser's initial directory into user directory
     * @param fileChooser 
     */
    public static void configureFileChooser(final FileChooser fileChooser) {
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
    }
    
    /**
     * Creates a pop up window and prompts the user for input for  the text for a label
     * @param type the widget type that the user is being prompted about
     * @param copyStage simply used so that we can make our text prompts be separated 
     * @return a string that either is containing the text the user entered or nothing
     * if the user opted to not enter anything
     */
    public static String promptInput(String type, Stage copyStage){
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initOwner(copyStage);
        VBox vbox = new VBox(10);
        vbox.getChildren().add(new Label("Enter " + type + " Text"));
        TextField tf = new TextField();
        tf.setMaxWidth(150);
        vbox.getChildren().add(tf);
        Button b = new Button("OK");
             
        b.setOnAction((ActionEvent event1) -> {
            if (tf.getText().isEmpty())
                System.out.println("Will go with default label");
            dialog.close();
            
        });
        vbox.getChildren().add(b);
        vbox.alignmentProperty().setValue(Pos.CENTER);
        Scene dialogScene = new Scene(vbox, 300, 200);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
        
        return tf.getText(); 
    }
}
